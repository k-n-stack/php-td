<?php

class Enemy {

    private $name;
    private $healthPoint;
    private $attackPoint;

    private $path = ['6x9','6x8','6x7','6x6','6x5','5x5','4x5','3x5','2x5','2x4','2x3','2x2','3x2','4x2','4x3','5x3','6x3','7x3','8x3','8x2','8x1'];
    private $pathPos = 0;

    function __construct($obName, $obHealthPoint, $obAttackPoint) {

        $this->name = $obName;
        $this->healthPoint = $obHealthPoint;
        $this->attackPoint = $obAttackPoint;

    }

    ### SETER
    function set_position(){

        $this->pathPos++;
        
    }

    ### GETER
    function get_positionY(){
        $position = $this->path[$this->pathPos];
        return (int)substr($position,0,1);
    }

    function get_positionX(){
        $position = $this->path[$this->pathPos];
        return (int)substr($position,2,1);
    }

    public function placeOnLayout(){
        return '<div class="enemy" id="l'.$this->get_positionY().'x'.$this->get_positionX().'">hp:'.$this->healthPoint.'</div>';
    }

    ### METHOD


    
    function show() {

    }

    function moveFoward() {

    }
}