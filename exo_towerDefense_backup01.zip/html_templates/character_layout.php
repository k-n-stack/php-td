<?php

function print_CLayout() {

    require_once 'object.php';

    echo '<div class="layout">';

    for ( $y=1 ; $y<=9 ; $y++ ) {
        for ( $x=1 ; $x<=9 ; $x++ ) {

            if ( $y == $test->get_positionY() && $x == $test->get_positionX() ) {
                echo $test->placeOnLayout();
            }
            else {
                echo '<div class="enemy" id="l'.$y.'x'.$x.'"></div>';
            }

        }
    }

    echo '</div>';

}