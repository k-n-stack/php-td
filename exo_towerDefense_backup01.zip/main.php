<?php

require_once 'html_templates\head.php';
require_once 'html_templates\map.php';
require_once 'html_templates\UI_pannel.php';
require_once 'html_templates\foot.php';
require_once 'html_templates\character_layout.php';

require_once 'class\UserInterface.php';
require_once 'class\Enemy.php';
require_once 'class\Tower.php';

// require_once 'object.php';

// if ( isset($_POST['submit']) or !empty($_POST['submit']) ) {
//     if ($_POST['submit'] == "next_turn") {
//         $test->set_position();
//     }    
// }

print_Head();
print_Map();
print_CLayout();
print_UI();
print_Foot();
var_dump($_POST);
?>