<?php

require_once 'class\UserInterface.php';
require_once 'class\Enemy.php';
require_once 'class\Tower.php';

// if (!isset($test)) {
$test = new Enemy('enemyTest',100,5);
// }
