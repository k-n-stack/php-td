<?php

require_once 'class\Enemy.php';

class ObjectPooler {

    private $wave = 1;

    function __construct() {

    }

    function set_Enemy($obName, $obHealthPoint, $obAttackPoint) {
        $atrName = "enemy".$this->wave;
        $this->$atrName = new Enemy($obName, $obHealthPoint, $obAttackPoint);
        // $this->enemy.(string)$this->$wave = new Enemy($obName, $obHealthPoint, $obAttackPoint);
        $this->wave++;
    }

    function print_Enemy() {

        echo '<div class="layout">';

        for ( $y=1 ; $y<=9 ; $y++ ) {
            for ( $x=1 ; $x<=9 ; $x++ ) {

                $bool = false;
    
                foreach ($this as $value) {

                    if (is_object($value)) {

                        if ( $y == $value->get_positionY() && $x == $value->get_positionX() ) {
                            // echo $value->placeOnLayout();
                            $bool = true;
                        }
                        // else {
                        //     echo '<div class="layoutcase" id="l'.$y.'x'.$x.'"></div>';
                        // }

                    }
                
                }

                if ( $bool==true ) {
                    echo $value->placeOnLayout();
                }

                if ( $bool==false ) {
                    echo '<div class="layoutcase" id="l'.$y.'x'.$x.'"></div>';
                }
    
            }

        }
    
        echo '</div>';
    
    }
}