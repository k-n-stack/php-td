<?php

require_once 'html_templates\head.php';
require_once 'html_templates\map.php';
require_once 'html_templates\UI_pannel.php';
require_once 'html_templates\foot.php';

require_once 'class\UserInterface.php';
require_once 'class\Enemy.php';
require_once 'class\Tower.php';
require_once 'class\ObjectPooler.php';


if ( !isset($OP) or empty($OP) ) {
    $OP = new ObjectPooler();
}
// var_dump($test);
$OP->set_Enemy('test',100,10);
// var_dump($test);
// $test->enemy2->set_position();
// echo "\n";

// $test->set_Enemy('test',100,10);
// var_dump($test);

if ( isset($_POST['submit']) or !empty($_POST['submit']) ) {
    if ($_POST['submit'] == "next_turn") {
        foreach ($OP as $value) {
            if (is_object($value)) {
                var_dump($OP);
                var_dump($value);
                $value->set_position();
            }
        }
    }    
}

print_Head();
print_Map();
$OP->print_Enemy();
print_UI();
print_Foot();
var_dump($_POST);
?>