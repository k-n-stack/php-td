<?php

class Enemy {

    private $name;
    private $healthPoint;
    private $attackPoint;

    private $path = ['6x9','6x8','6x7','6x6','6x5','5x5','4x5','3x5','2x5','2x4','2x3','2x2','3x2','4x2','4x3','5x3','6x3','7x3','8x3','8x2','8x1'];
    private $pathPos;

    function __construct($obName, $obHealthPoint, $obAttackPoint, $obPathPos = 0) {

        $this->name = $obName;
        $this->healthPoint = $obHealthPoint;
        $this->attackPoint = $obAttackPoint;
        $this->pathPos = $obPathPos;

    }

    ### SETER
    function set_position(){

        if ($this->pathPos <= count($this->path) - 2 ) {
        $this->pathPos = $this->pathPos+1;
        }
        
    }

    ### GETER
    function get_positionY(){
        $position = $this->path[$this->pathPos];
        return (int)substr($position,0,1);
    }

    function get_positionX(){
        $position = $this->path[$this->pathPos];
        return (int)substr($position,2,1);
    }

    public function placeOnLayout(){
        return '<div class="layoutcase enemy" id="l'.$this->get_positionY().'x'.$this->get_positionX().'"><img src="images\enemy1.png" height="30" width="30">hp:'.$this->healthPoint.'</div>';
    }

    ### METHOD


    
    function show() {

    }

    function moveFoward() {

    }
}