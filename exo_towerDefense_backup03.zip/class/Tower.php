<?php

class Tower {

    private $name;
    private $level = 1;
    private $posX;
    private $posY;
    private $buildCost;
    
    private $attackPower;
    private $range;

    function __construct($obName, $obLevel, $obPosX, $obPosY, $obBuildCost, $obattackPower, $obRange) {

        $this->name = $obName;
        $this->level = $obLevel;
        $this->posX = $obPosX;
        $this->posY = $obPosY;
        $this->buildCost = $obBuildCost;

        $this->attackPower = $obattackPower;
        $this->range = $obRange;

    }

    ######### SETER ############
    function set_Name(){}

    function set_Level(){}

    function set_Position(){}

    function set_BuildCost(){}

    function set_AttackPower(){}

    function set_Range(){}

    ######### GETER ############
    function get_Name(){}

    function get_Level(){}

    function get_Position(){}

    function get_BuildCost(){}

    function get_AttackPower(){}

    function get_Range(){}

    ######### METHODS ############
    function attack() {

    }

    function upgrade() {

    }

    function delete() {

    }

    function show() {

        echo "Tour : $this->name.</br>";
        echo "Level : $this->level.</br>";
        echo "PosX : $this->posX, PosY : $this->posY.</br>";
        echo "Cost : $this->buildCost.</br>";
        echo "Attack-Power : $this->attackPower.</br>";
        echo "Range ; $this->range.</br>";
        
    }
    
}