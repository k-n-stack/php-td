<?php

class UserInterface {

    private $lifePoint;
    private $gold;

    function __construct($obLifePoint,$obGold) {

        $this->lifePoint = $obLifePoint;
        $this->gold = $obGold;

    }

    function decreaseLife() {

    }

    function spendGold() {

    }

    function winGold() {

    }
    
}