<?php

$_SESSION[]

if ($turn == 0
    or $turn == 2
    or $turn == 3
    or $turn == 4
    or $turn == 7
    or $turn == 8
    or $turn == 9
    or $turn == 12
    or $turn == 13
    or $turn == 14
    or $turn == 15
    or $turn == 16
    or $turn == 18
    or $turn == 19
    or $turn == 20
)

{
$_SESSION['main']->set_Enemy('test',100,10);
$turn++;
}

$turn++;