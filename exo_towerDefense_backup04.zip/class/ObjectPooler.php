<?php

require_once 'class\Enemy.php';

class ObjectPooler {

    private $wave = 1;

    function __construct() {

    }

    function kill_Enemy($obEnemy) {
        unset($this->$obEnemy);
    }

    function set_Enemy($obName, $obHealthPoint, $obAttackPoint) {########################################################################################################################################
        $atrName = "enemy".$this->wave;
            // if ( isset($this->$atrName) or !empty($this->$atrName) ) {
            $this->$atrName = new Enemy($obName, $obHealthPoint, $obAttackPoint, $this->wave);
            // }
        // $this->enemy.(string)$this->$wave = new Enemy($obName, $obHealthPoint, $obAttackPoint);
        $this->wave++;
    }

    function print_Enemy() {

        echo '<div class="layout">';

        for ( $y=1 ; $y<=9 ; $y++ ) {
            for ( $x=1 ; $x<=9 ; $x++ ) {

                $bool = false;
    
                foreach ($this as $value) {

                    if (is_object($value)) {

                        if ( $y == $value->get_positionY() and $x == $value->get_positionX() ) {
                            // echo $value->placeOnLayout();
                            $bool = true;
                        }
                        // else {
                        //     echo '<div class="layoutcase" id="l'.$y.'x'.$x.'"></div>';
                        // }

                    }
                
                }

                if ( $bool==true ) {
                    echo $value->placeOnLayout();
                }

                if ( $bool==false ) {

                    if ( $y == 8 and $x == 1 ) {

                        echo '<div class="layoutcase homelayout" id="l'.$y.'x'.$x.'"><img src="images\home.png" height="40" width="50">hp : '.$_SESSION['UI']->get_lifePoint().'</div>';

                    }

                    else {
                        
                        echo '<div class="layoutcase" id="l'.$y.'x'.$x.'"></div>';

                    }
                }
    
            }

        }
    
        echo '</div>';
    
    }
}