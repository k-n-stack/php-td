<?php

function print_UI() {
echo <<< UI
<div id='inputpanel'>

    <div id='action'>
        <form action="main.php" method="post">
            <input type="submit" name="submit" value="next_turn">
        </form>
    </div>

    <div id='stat'>
    </div>

</div>
UI;
}