<?php

class UserInterface {

    private $lifePoint;
    private $gold;

    function __construct($obLifePoint,$obGold) {

        $this->lifePoint = $obLifePoint;
        $this->gold = $obGold;

    }

    function get_lifePoint() {
        return $this->lifePoint;
    }

    function takeDamage($attackPoint) {
        $this->lifePoint -= $attackPoint;
    }

    function decreaseLife() {

    }

    function spendGold() {

    }

    function winGold() {

    }
    
    
}