<?php

function print_GameOver() {
    echo <<< GO
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Game Over</title>
    </head>
    <body id='go'>
        
        <div>
            <img id='goimg' src="images\go.png" width="500px" height="500px">
            <p id='gomsg'>Enemy Destroyed Your Home !</p>
        </div>
    
    </body>
    </html>
GO;
}