<?php

require_once 'html_templates\head.php';
require_once 'html_templates\map.php';
require_once 'html_templates\UI_pannel.php';
require_once 'html_templates\foot.php';
require_once 'html_templates\gameover.php';

require_once 'class\UserInterface.php';
require_once 'class\Enemy.php';
require_once 'class\Tower.php';
require_once 'class\ObjectPooler.php';


session_start();

// echo "post : ";
// var_dump($_POST);
// echo "||| ";
// echo "session turn : ";
// var_dump($_SESSION['turn']);
// echo "\n";
// var_dump($_SESSION['OP']);

if ( !isset($_SESSION['UI']) or empty($_SESSION['UI']) ) {
    $_SESSION['UI'] = new UserInterface(100, 50);
}

if ( !isset($_SESSION['OP']) or empty($_SESSION['OP']) ) {
    $_SESSION['OP'] = new ObjectPooler();
}

if ( !isset($_SESSION['turn']) or empty($_SESSION['turn']) ) {
    $_SESSION['turn'] = 0;  
}

####################################################################

if ( isset($_POST['submit']) or !empty($_POST['submit']) ) {
    if ($_POST['submit'] == "next_turn") {

        foreach ($_SESSION['OP'] as $value) {
            if (is_object($value)) {
                $value->set_position();
            }
        }

        $_SESSION['turn']++;

    }    
}

// echo "post : ";
// var_dump($_POST);
// echo "||| ";
echo "session turn : ";
var_dump($_SESSION['turn']);
// echo "\n";
// var_dump($_SESSION['OP']);

$waveManager = [1,3,4,6,7,8,12,13,14,15,16,19,22,23,24,25,26,27];

foreach ($waveManager as $value) {
    if ($_SESSION['turn'] == $value) {
        $_SESSION['OP']->set_Enemy('test',100,15);
        echo "yo";
    }
}

if ( isset($_SESSION['OP']) or !empty($_SESSION['OP']) ) {
    foreach ( $_SESSION['OP'] as $value ) {
        if ($value instanceof Enemy) {
            if ( $value->get_pathPos() == count( $value->get_path() ) - 1 ) {
                $_SESSION['OP']->kill_Enemy( "enemy".$value->get_enemyNb() );
                $_SESSION['UI']->takeDamage( $value->get_attackPoint() );

                if ( $_SESSION['UI']->get_lifePoint() <= 0 ) {
                    print_GameOver();
                    exit;
                }

            }
        }
    }
}

for ( $y=1 ; $y<=9 ; $y++ ) {
    for ( $x=1 ; $x<=9 ; $x++ ) {
        if ( isset($_POST['m'.$y.'x'.$x]) or !empty($_POST['m'.$y.'x'.$x]) ) {
            if ( $_POST['m'.$y.'x'.$x] == 'show' ) {
                echo 'hello m'.$y.'x'.$x;
            }
        } 
    }
}



print_Head();
print_Map();
$_SESSION['OP']->print_Enemy();
print_UI();
print_Foot();

// echo "post : ";
// var_dump($_POST);
// echo "||| ";
echo "session turn : ";
var_dump($_SESSION['turn']);
// echo "\n";
// var_dump($_SESSION['OP']);



?>