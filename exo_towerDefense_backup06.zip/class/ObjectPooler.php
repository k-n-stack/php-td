<?php

require_once 'class\Enemy.php';
require_once 'class\Tower.php';

class ObjectPooler {

    private $wave = 1;
    private $towerNb = 1;

    function __construct() {

    }

    function kill_Enemy($obEnemy) {
        unset($this->$obEnemy);
    }

    function set_Enemy($obName, $obHealthPoint, $obAttackPoint) {
        $atrName = "enemy".$this->wave;
        $this->$atrName = new Enemy($obName, $obHealthPoint, $obAttackPoint, $this->wave);
        $this->wave++;
    }

    function set_Tower($obName, $obBuildCost, $obattackPower, $obRange, $obPosY, $obPosX) {
        $atrName = $obName.$this->towerNb;
        $this->$atrName = new Tower($obName, $obBuildCost, $obattackPower, $obRange, $obPosY, $obPosX);
        $this->towerNb++;
        // echo $this->towerNb;
    }

    // function set_Tower( )

    // function set_Tower()

    function print_Layout() {

        echo '<div class="layout">';

        // for ( $y=1 ; $y<=9 ; $y++ ) {
        //     for ( $x=1 ; $x<=9 ; $x++ ) {

        //         $bool = false;
    
        //         foreach ($this as $value) {

        //             if ($value instanceof Enemy) {

        //                 if ( $y == $value->get_positionY() and $x == $value->get_positionX() ) {
        //                     // echo $value->placeOnLayout();
        //                     $bool = true;
        //                 }
        //                 // else {
        //                 //     echo '<div class="layoutcase" id="l'.$y.'x'.$x.'"></div>';
        //                 // }

        //             }
                
        //         }

        //         if ( $bool==true ) {
                    
        //             // if ( $value instanceof Enemy) {
        //                 echo $value->placeOnLayout();
        //             // }
        //         }

        //         if ( $bool==false ) {

        //             if ( $y == 8 and $x == 1 ) {

        //                 echo '<div class="layoutcase homelayout" id="l'.$y.'x'.$x.'"><img src="images\home.png" height="40" width="50">hp : '.$_SESSION['UI']->get_lifePoint().'</div>';

        //             }

        //             else {
                        
        //                 echo '<div class="layoutcase" id="l'.$y.'x'.$x.'"></div>';

        //             }
        //         }
    
        //     }

        // }


        for ( $y=1 ; $y<=9 ; $y++ ) {
            for ( $x=1 ; $x<=9 ; $x++ ) {

                $bool = false;

                foreach ($this as $value) {
                    if ($value instanceof Enemy or $value instanceof Tower) {
                        if ( $y == $value->get_positionY() and $x == $value->get_positionX() ) {
                            $bool = true;
                        }
                    }
                }

                if ( $bool==true ) {
                        echo $value->placeOnLayout();
                }

                if ( $bool==false ) {
                    if ( $y == 8 and $x == 1 ) {
                        echo '<div class="layoutcase homelayout" id="l'.$y.'x'.$x.'"><img src="images\home.png" height="40" width="50">hp : '.$_SESSION['UI']->get_lifePoint().'</div>';
                    }
                    else {
                        echo '<div class="layoutcase" id="l'.$y.'x'.$x.'"></div>';
                    }
                }
    
            }

        }
    
        echo '</div>';
    
    }
}