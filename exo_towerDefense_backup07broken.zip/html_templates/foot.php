<?php
function print_Foot() {
echo <<< FOOT
</body>
</html>
FOOT;
}