<?php

// function __construct($obName, $obBuildCost, $obattackPower, $obRange, $obPosY = 0, $obPosX = 0)
$arrowTower = new Tower('Arrow_Tower', 50, 1, 1, 0, 0);
$fireTower = new Tower('Fire_Tower', 150, 2, 2, 0, 0);
$lazerTower = new Tower('Lazer_Tower', 400, 4, 3, 0, 0);