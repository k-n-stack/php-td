<?php

class Tower {

    private $name;
    private $posX;
    private $posY;
    private $buildCost;
    
    private $attackPower;
    private $range;

    function __construct($obName, $obBuildCost, $obattackPower, $obRange, $obPosY, $obPosX) {

        $this->name = $obName;
        $this->posY = $obPosY;
        $this->posX = $obPosX;

        $this->buildCost = $obBuildCost;
        $this->attackPower = $obattackPower;
        $this->range = $obRange;

    }

    public function get_name() {
        return $this->name;
    }

    public function get_positionY() {
        return $this->posY;
    }

    public function get_positionX() {
        return $this->posX;
    }

    public function get_buildCost() {
        return $this->buildCost;
    }

    public function get_attackPower() {
        return $this->attackPower;        
    }

    public function get_range() {
        return $this->range;
    }

    public function placeOnLayout() {
        return '<div class="layoutcase tower" id="l'.$this->get_positionY().'x'.$this->get_positionX().'"><img src="images\arrow.png" height="30" width="30">atk:'.$this->attackPower.'</div>';
    }

    function show() {

        echo "Tour : $this->name.</br>";
        echo "Level : $this->level.</br>";
        echo "PosX : $this->posX, PosY : $this->posY.</br>";
        echo "Cost : $this->buildCost.</br>";
        echo "Attack-Power : $this->attackPower.</br>";
        echo "Range ; $this->range.</br>";
        
    }
    
}